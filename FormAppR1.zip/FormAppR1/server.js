import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.use(express.static(__dirname)); // serve files from current directory
console.log("started");
app.get('/', (req, res) => {
    console.log("Inside")
  res.sendFile(path.join(__dirname, 'index.html'));
});

const PORT = 3010;
app.listen(PORT, () => console.log(`🚀 App running at http://localhost:${PORT}`));
console.log("Ended");