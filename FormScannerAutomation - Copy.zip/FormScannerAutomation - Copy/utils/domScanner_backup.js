export class DOMScanner {
    constructor(page) {
      this.page = page;
    }
  
    async scanVisibleActionableElements() {
      return await this.page.evaluate(() => {
        const results = [];
        const tags = ['input', 'button', 'select', 'textarea', 'a', 'label', 'h1', 'h2', 'h3', 'p', 'div', 'span'];
  
        function generateRelativeXPath(el) {
          if (el.id) return `//*[@id="${el.id}"]`;
          if (el.name) return `//${el.tagName.toLowerCase()}[@name="${el.name}"]`;
          const text = el.innerText?.trim() || el.value?.trim();
          if (text) return `//${el.tagName.toLowerCase()}[normalize-space(text())="${text}"]`;
  
          const siblings = Array.from(el.parentNode?.children || []);
          const index = siblings.indexOf(el) + 1;
          return `(${el.tagName.toLowerCase()})[${index}]`;
        }
  
        const elements = Array.from(document.querySelectorAll(tags.join(',')));
  
        for (const el of elements) {
          const rect = el.getBoundingClientRect();
          if (rect.width > 0 && rect.height > 0) {
            const tag = el.tagName.toLowerCase();
            const text = el.innerText?.trim() || el.value?.trim() || '';
            if (!text) continue;
  
            results.push({
              tag,
              text,
              relativeXPath: generateRelativeXPath(el),
            });
          }
        }
  
        return results;
      });
    }
  }
  