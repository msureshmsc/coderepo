import { test, expect } from '@playwright/test';
import fs from 'fs';
import path from 'path';
import * as XLSX from 'xlsx';

test('Compare Baseline and Release 1', async () => {
  // Folders
  const baselineFolder = path.join('TestReports', 'baseline_2025-04-14T16-14-17-624Z');
  const releaseFolder = path.join('TestReports', 'release1_2025-04-15T01-38-07-638Z');
  const comparisonFolder = path.join('comparisonresults');
  const excelDir = path.join(comparisonFolder, 'DomComparisonExcel');

  // Ensure comparison folder structure exists
  fs.mkdirSync(excelDir, { recursive: true });

  // Paths
  const baselineExcelPath = path.join(baselineFolder, 'DomInExcel', 'BaselineData.xlsx');
  const releaseExcelPath = path.join(releaseFolder, 'DomInExcel', 'Release1Data.xlsx');

  // Read Excel Files
//   function readExcel(filePath) {
//     if (!fs.existsSync(filePath)) {
//       throw new Error(`❌ File not found: ${filePath}`);
//     }
//     const wb = XLSX.readFile(filePath);
//     const sheet = wb.Sheets[wb.SheetNames[0]];
//     return XLSX.utils.sheet_to_json(sheet, { header: 1 });
//   }

    function readExcel(filePath) {
        if (!fs.existsSync(filePath)) {
        throw new Error(`❌ File not found: ${filePath}`);
        }
        const data = fs.readFileSync(filePath); // read buffer
        const wb = XLSX.read(data, { type: 'buffer' }); // parse buffer
        const sheet = wb.Sheets[wb.SheetNames[0]];
        return XLSX.utils.sheet_to_json(sheet, { header: 1 });
    }
  

  const baselineData = readExcel(baselineExcelPath);
  const releaseData = readExcel(releaseExcelPath);

  // Convert rows to map for fast lookup: assume 1st col is field identifier
  const toMap = (data) => {
    const map = new Map();
    for (let i = 1; i < data.length; i++) {
      map.set(data[i][0], data[i]); // Key = field identifier
    }
    return map;
  };

  const baselineMap = toMap(baselineData);
  const releaseMap = toMap(releaseData);

  // Compare
  const results = [['FieldIdentifier', 'Status', 'Baseline Value', 'Release Value']];
  const releaseKeys = new Set(releaseMap.keys());

  for (const [key, baseRow] of baselineMap.entries()) {
    if (releaseMap.has(key)) {
      const relRow = releaseMap.get(key);
      const isSame = JSON.stringify(baseRow) === JSON.stringify(relRow);
      results.push([key, isSame ? 'MATCH' : 'MISMATCH', JSON.stringify(baseRow), JSON.stringify(relRow)]);
      releaseKeys.delete(key);
    } else {
      results.push([key, 'DELETED', JSON.stringify(baseRow), '']);
    }
  }

  // New fields in release
  for (const newKey of releaseKeys) {
    const relRow = releaseMap.get(newKey);
    results.push([newKey, 'NEW FIELD', '', JSON.stringify(relRow)]);
  }

  // Write comparison Excel
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(results);
  XLSX.utils.book_append_sheet(wb, ws, 'Comparison');

  const comparisonExcelPath = path.join(excelDir, 'ComparisonResults.xlsx');
  XLSX.writeFile(wb, comparisonExcelPath);

  console.log(`✅ Comparison complete. Excel saved at: ${comparisonExcelPath}`);
});
