import { test } from '@playwright/test';
import { DOMScanner } from '../utils/domScanner.js';
import * as XLSX from 'xlsx';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function getTimestamp() {
  return new Date().toISOString().replace(/[:.]/g, '-');
}

test('Capture Release 1 screenshots and DOM info', async ({ page }) => {
  const timestamp = getTimestamp();
  const baseDir = path.join(__dirname, '..', 'TestReports', `release1_${timestamp}`);
  const pageSSDir = path.join(baseDir, 'screenshots', 'pages');
  const fieldSSDir = path.join(baseDir, 'screenshots', 'fields');
  const excelDir = path.join(baseDir, 'DomInExcel');

  // Create necessary directories
  fs.mkdirSync(baseDir, { recursive: true });
  fs.mkdirSync(pageSSDir, { recursive: true });
  fs.mkdirSync(fieldSSDir, { recursive: true });
  fs.mkdirSync(excelDir, { recursive: true });

  // Update config with release1 folder info
  const configPath = path.join(__dirname, '..', 'config.json');
  let config = {};
  if (fs.existsSync(configPath)) {
    config = JSON.parse(fs.readFileSync(configPath));
  }
  config.release1Folder = `release1_${timestamp}`;
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));

  // Launch Release 1 app
  await page.goto('http://localhost:3010');

  // === 1. Capture full page screenshot ===
  await page.screenshot({ path: path.join(pageSSDir, 'fullPage.png'), fullPage: true });

  // === 2. Scan DOM elements ===
  const scanner = new DOMScanner(page);
  const elements = await scanner.scanVisibleActionableElements();

  const worksheetData = [['tag', 'text', 'id', 'name', 'type', 'forLabelValue', 'relativeXPath']];
  let fieldScreenshotCount = 0;

  for (const { tag, text, id, name, type, forLabelValue, relativeXPath } of elements) {
    worksheetData.push([tag, text, id, name, type, forLabelValue, relativeXPath]);

    try {
      const handle = await page.$(relativeXPath);
      if (handle) {
        const safeText = (text || '')
          .toLowerCase()
          .replace(/[^a-z0-9]/gi, '')
          .substring(0, 30); // Truncate for safe filenames

        const cleanName = name?.toLowerCase().replace(/[^a-z0-9]/gi, '') || '';
        const filename = `${tag}_${cleanName || safeText || 'element'}.png`;

        await handle.screenshot({ path: path.join(fieldSSDir, filename) });
        fieldScreenshotCount++;
      }
    } catch (err) {
      console.warn(`⚠️ Skipping screenshot for: ${relativeXPath}`);
    }
  }

  // === 3. Write DOM data to Excel ===
  const workbook = XLSX.utils.book_new();
  const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);
  XLSX.utils.book_append_sheet(workbook, worksheet, 'RELEASE1');
  XLSX.writeFile(workbook, path.join(excelDir, 'Release1Data.xlsx'));

  console.log(`✅ Release 1 page screenshot saved.`);
  console.log(`✅ Captured ${fieldScreenshotCount} field screenshots.`);
  console.log(`✅ Excel file created at: ${path.join(excelDir, 'Release1Data.xlsx')}`);
});
