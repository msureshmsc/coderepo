import { test, expect } from '@playwright/test';
import * as XLSX from 'xlsx/xlsx.mjs';
import fs from 'fs';
import path from 'path';
import pixelmatch from 'pixelmatch';
import { PNG } from 'pngjs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function readExcel(filePath) {
  const data = fs.readFileSync(filePath);
  const workbook = XLSX.read(data, { type: 'buffer' });
  const sheet = workbook.Sheets[workbook.SheetNames[0]];
  return XLSX.utils.sheet_to_json(sheet, { header: 1 });
}

function loadImage(filePath) {
  return PNG.sync.read(fs.readFileSync(filePath));
}

function compareImages(img1Path, img2Path, diffPath) {
  const img1 = loadImage(img1Path);
  const img2 = loadImage(img2Path);
  const { width, height } = img1;
  const diff = new PNG({ width, height });

  const mismatch = pixelmatch(img1.data, img2.data, diff.data, width, height, { threshold: 0.1 });
  fs.writeFileSync(diffPath, PNG.sync.write(diff));
  return mismatch;
}

// ✅ Playwright test block — ensures it's recognized as a test
test('Compare DOM and Visuals between Baseline and Release 1', async () => {
  const config = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'config.json')));
  const baselineFolder = path.join(__dirname, '..', 'TestReports', config.baselineFolder);

  const releaseFolder = fs.readdirSync(path.join(__dirname, '..', 'TestReports'))
    .filter(f => f.startsWith('release1_'))
    .map(f => path.join(__dirname, '..', 'TestReports', f))
    .sort((a, b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs)[0];

  const comparisonFolder = path.join(__dirname, '..', 'comparisonresults');
  const pageDiffDir = path.join(comparisonFolder, 'screenshots', 'pages');
  const fieldDiffDir = path.join(comparisonFolder, 'screenshots', 'fields');
  const excelDir = path.join(comparisonFolder, 'DomComparisonExcel');
  [comparisonFolder, pageDiffDir, fieldDiffDir, excelDir].forEach(dir => fs.mkdirSync(dir, { recursive: true }));

  const baselineExcel = readExcel(path.join(baselineFolder, 'DomInExcel', 'BaselineData.xlsx'));
  const releaseExcel = readExcel(path.join(releaseFolder, 'DomInExcel', 'Release1Data.xlsx'));

  const baselineMap = new Map();
  for (let i = 1; i < baselineExcel.length; i++) {
    const row = baselineExcel[i];
    baselineMap.set(row[6], row); // relativeXPath as key
  }

  const resultData = [['tag', 'text', 'id', 'name', 'type', 'forLabelValue', 'relativeXPath', 'Status', 'Error']];

  for (let i = 1; i < releaseExcel.length; i++) {
    const row = releaseExcel[i];
    const xpath = row[6];

    if (baselineMap.has(xpath)) {
      const baselineRow = baselineMap.get(xpath);
      const isMatch = JSON.stringify(row.slice(0, 6)) === JSON.stringify(baselineRow.slice(0, 6));
      const safeField = (row[1] || row[3] || xpath).replace(/[^a-z0-9]/gi, '_').substring(0, 40);

      if (!isMatch) {
        const baseImg = path.join(baselineFolder, 'screenshots', 'fields', `${baselineRow[0]}_${safeField}.png`);
        const releaseImg = path.join(releaseFolder, 'screenshots', 'fields', `${row[0]}_${safeField}.png`);
        const diffImg = path.join(fieldDiffDir, `${row[0]}_${safeField}_diff.png`);

        let mismatch = 'N/A';
        if (fs.existsSync(baseImg) && fs.existsSync(releaseImg)) {
          mismatch = compareImages(baseImg, releaseImg, diffImg);
        }

        resultData.push([...row, 'MISMATCH', `Mismatch pixels: ${mismatch}`]);
      } else {
        resultData.push([...row, 'MATCH', '']);
      }

      baselineMap.delete(xpath);
    } else {
      resultData.push([...row, 'NEW FIELD', 'Field only in Release 1']);
    }
  }

  // Fields that were deleted (present in baseline but not in release)
  for (const [xpath, row] of baselineMap.entries()) {
    resultData.push([...row, 'DELETED', 'Field missing in Release 1']);
  }

  // Write comparison result to Excel
  const workbook = XLSX.utils.book_new();
  const worksheet = XLSX.utils.aoa_to_sheet(resultData);
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Comparison');
  XLSX.writeFile(workbook, path.join(excelDir, 'ComparisonResult.xlsx'));

  console.log(`✅ Comparison complete. Excel file saved at ${path.join(excelDir, 'ComparisonResult.xlsx')}`);
});
