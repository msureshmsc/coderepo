import { test, expect } from '@playwright/test';
import * as XLSX from 'xlsx/xlsx.mjs';
import fs from 'fs';
import path from 'path';
import pixelmatch from 'pixelmatch';
import { PNG } from 'pngjs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function readExcel(filePath) {
  // const workbook = XLSX.readFile(filePath);
  const data = fs.readFileSync(filePath);
  const workbook = XLSX.read(data, { type: 'buffer' });

  const sheet = workbook.Sheets[workbook.SheetNames[0]];
  return XLSX.utils.sheet_to_json(sheet, { header: 1 });
}

function loadImage(filePath) {
  return PNG.sync.read(fs.readFileSync(filePath));
}

function compareImages(img1Path, img2Path, diffPath) {
  const img1 = loadImage(img1Path);
  const img2 = loadImage(img2Path);
  const { width, height } = img1;
  const diff = new PNG({ width, height });

  const mismatch = pixelmatch(img1.data, img2.data, diff.data, width, height, { threshold: 0.1 });
  fs.writeFileSync(diffPath, PNG.sync.write(diff));
  return mismatch;
}

test('Compare Baseline and Release 1', async () => {
  const config = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'config.json')));
  const baselineFolder = path.join(__dirname, '..', 'TestReports', config.baselineFolder);
  const releaseFolder = fs.readdirSync(path.join(__dirname, '..', 'TestReports'))
    .filter(f => f.startsWith('release1_'))
    .map(f => path.join(__dirname, '..', 'TestReports', f))
    .sort((a, b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs)[0];

  const comparisonFolder = path.join(__dirname, '..', 'comparisonresults');
  const pageDiffDir = path.join(comparisonFolder, 'screenshots', 'pages');
  const fieldDiffDir = path.join(comparisonFolder, 'screenshots', 'fields');
  const excelDir = path.join(comparisonFolder, 'DomComparisonExcel');
  [comparisonFolder, pageDiffDir, fieldDiffDir, excelDir].forEach(dir => fs.mkdirSync(dir, { recursive: true }));

  const baselineExcel = readExcel(path.join(baselineFolder, 'DomInExcel', 'BaselineData.xlsx'));
  const releaseExcel = readExcel(path.join(releaseFolder, 'DomInExcel', 'Release1Data.xlsx'));
  
  const baselineMap = new Map();
  for (let i = 1; i < baselineExcel.length; i++) {
    const row = baselineExcel[i];
    baselineMap.set(row[6], row); // relativeXPath as key
  }

  const resultData = [['tag', 'text', 'id', 'name', 'type', 'forLabelValue', 'relativeXPath', 'Status', 'Error']];

  for (let i = 1; i < releaseExcel.length; i++) {
    const row = releaseExcel[i];
    const xpath = row[6];
    if (baselineMap.has(xpath)) {
      const baselineRow = baselineMap.get(xpath);
      const isMatch = JSON.stringify(row.slice(0, 6)) === JSON.stringify(baselineRow.slice(0, 6));
      const fieldName = xpath.replace(/[^a-z0-9]/gi, '_').slice(0, 40);

      if (!isMatch) {
        // Screenshot diff
        const baseImg = path.join(baselineFolder, 'screenshots', 'fields', `${baselineRow[0]}_${fieldName}.png`);
        const releaseImg = path.join(releaseFolder, 'screenshots', 'fields', `${row[0]}_${fieldName}.png`);
        const diffImg = path.join(fieldDiffDir, `${row[0]}_${fieldName}_diff.png`);
        let mismatchCount = 0;

        if (fs.existsSync(baseImg) && fs.existsSync(releaseImg)) {
          mismatchCount = compareImages(baseImg, releaseImg, diffImg);
        }

        resultData.push([...row, 'MISMATCH', `Modified field. Pixels Mismatched: ${mismatchCount}`]);
      } else {
        resultData.push([...row, 'MATCH', '']);
      }

      baselineMap.delete(xpath);
    } else {
      resultData.push([...row, 'NEW FIELD', 'Not present in Baseline']);
    }
  }

  // Remaining in baselineMap are DELETED
  for (let [xpath, row] of baselineMap.entries()) {
    resultData.push([...row, 'DELETED', 'Removed in Release 1']);
  }

  const wb = XLSX.utils.book_new();

  const worksheet = XLSX.utils.aoa_to_sheet(resultData);
  XLSX.utils.book_append_sheet(wb, worksheet, 'Comparison');

  // Ensure folder exists
  if (!fs.existsSync(excelDir)) {
    fs.mkdirSync(excelDir, { recursive: true });
  }

  // Build path
  const excelFilePath = path.join(excelDir, 'ComparisonResults.xlsx');

  // Delete if already exists
  if (fs.existsSync(excelFilePath)) {
    fs.unlinkSync(excelFilePath);
  }

  // Write the file
  XLSX.writeFile(wb, excelFilePath);


  console.log('✅ Comparison completed. Excel and diff screenshots saved.');
});
